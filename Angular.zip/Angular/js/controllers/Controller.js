app.controller('MainController', ['$scope', function($scope){
	$scope.name = 'Adriaan';

	$scope.posts = [
		{
			text: 'This is a post',
			challengeCount: 0,
			r_count: 1,
			replies: [
				{
					r_text: 'One reply'
				}
			]
		}
	];

	$scope.addPost = function(){
		$scope.posts.push({
			text: $scope.posts.postText,
			challengeCount: 0,
			r_count: 0,
			replies: [{
				r_text: null
			}]
		});
		$scope.posts.postText = '';
	};

	$scope.addReply = function($index){
		var text = new Object
		$scope.posts[$index].replies.push({
			r_text: $scope.posts[$index].replyText
		});
		// r_text: $scope.posts[$index].replyText
		$scope.posts[$index].r_count += 1;
		$scope.posts[$index].replyText = '';
	};

	$scope.challengeAccepted = function($index){
		$scope.posts[$index].challengeCount += 1;
	};

}]);
