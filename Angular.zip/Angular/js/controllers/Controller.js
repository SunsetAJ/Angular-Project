app.controller('MainController', ['$scope', function($scope){
	$scope.name = 'Adriaan';

	$scope.posts = [
		{
			text: 'This is a post'
		}
	];

	$scope.addPost = function(){
		$scope.posts.push({
			text: $scope.posts.postText
		});
		$scope.posts.postText = '';
	};

}]);